# Tdarr Plugin Runner

plugin for [Unmanic](https://github.com/Unmanic)
