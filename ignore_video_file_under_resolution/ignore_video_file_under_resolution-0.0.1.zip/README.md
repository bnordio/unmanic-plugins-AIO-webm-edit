# Ignore files under resolution

plugin for [Unmanic](https://github.com/Unmanic)
